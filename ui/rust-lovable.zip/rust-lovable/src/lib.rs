pub mod app;
pub mod components;
pub mod core;
pub mod utils;
pub mod config;
pub mod resources;
pub mod compression;
pub mod metadata;
pub mod ml_devops;
pub mod vibe_coding;

// Re-export main app
pub use app::App;